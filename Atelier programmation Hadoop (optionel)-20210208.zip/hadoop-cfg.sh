
export JAVA_HOME=/mnt/n7fs/ens/tp_dh/jdk1.8.0_45
export PATH=$JAVA_HOME/bin:$PATH

export HADOOP_HOME=<your-path>/hadoop-2.7.1
export PATH=$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH

